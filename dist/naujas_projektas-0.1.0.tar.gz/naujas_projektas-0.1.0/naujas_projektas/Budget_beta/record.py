class Record:
    def __init__(self, amount):
        self.amount = amount
